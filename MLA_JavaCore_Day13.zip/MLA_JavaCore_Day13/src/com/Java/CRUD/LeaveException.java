package com.Java.CRUD;
import java.util.*;
public class LeaveException extends Exception {
LeaveException(){
	
}

LeaveException(String error){
	super(error);
}
}
